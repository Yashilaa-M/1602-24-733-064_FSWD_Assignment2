import React, { useState, useEffect } from 'react';
import './Stopwatch.css';

/**
 * Stopwatch Component
 * 
 * Requirements satisfied:
 * - Uses `useState` for tracking time, running state, and laps
 * - Uses `useEffect` with `setInterval` to advance the timer
 * - Cleans up (clears the interval) via useEffect cleanup callback on unmount
 * - Displays Minutes and Seconds (along with centiseconds for precision)
 * - Has Start, Pause, and Reset buttons
 */
function Stopwatch() {
  // 1. useState: Track elapsed time in milliseconds
  const [time, setTime] = useState(0);

  // 2. useState: Track whether the stopwatch is actively running
  const [isRunning, setIsRunning] = useState(false);

  // Optional: Track recorded lap times
  const [laps, setLaps] = useState([]);

  // 3. useEffect: Timer interval management & automatic cleanup on unmount
  useEffect(() => {
    let intervalId = null;

    if (isRunning) {
      intervalId = setInterval(() => {
        setTime((prevTime) => prevTime + 10); // increments by 10ms
      }, 10);
    }

    // CRITICAL: Cleanup function runs when:
    // a) isRunning state changes (e.g., when user clicks Pause/Reset)
    // b) The component UNMOUNTS from the DOM, preventing memory leaks
    return () => {
      if (intervalId) {
        clearInterval(intervalId);
      }
    };
  }, [isRunning]);

  // Handler functions
  const handleStart = () => {
    setIsRunning(true);
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTime(0);
    setLaps([]);
  };

  const handleLap = () => {
    if (time > 0) {
      setLaps((prevLaps) => [time, ...prevLaps]);
    }
  };

  // Time calculations: converts milliseconds to Minutes, Seconds, and Hundredths
  const formatTimeParts = (ms) => {
    const minutes = Math.floor((ms / 60000) % 60);
    const seconds = Math.floor((ms / 1000) % 60);
    const hundredths = Math.floor((ms / 10) % 100);

    return {
      minutes: String(minutes).padStart(2, '0'),
      seconds: String(seconds).padStart(2, '0'),
      hundredths: String(hundredths).padStart(2, '0')
    };
  };

  const { minutes, seconds, hundredths } = formatTimeParts(time);

  // Current status helper
  const getStatus = () => {
    if (isRunning) return { label: 'Running', className: 'running' };
    if (time > 0) return { label: 'Paused', className: 'paused' };
    return { label: 'Idle (Ready)', className: 'idle' };
  };

  const status = getStatus();

  return (
    <div className="stopwatch-wrapper">
      {/* Status indicator */}
      <div className={`status-badge ${status.className}`}>
        <span className="status-dot"></span>
        <span>{status.label}</span>
      </div>

      {/* Main Digital Timer Display showing Minutes and Seconds */}
      <div className="timer-display" aria-label={`Timer: ${minutes} minutes, ${seconds} seconds`}>
        <div className="time-unit">
          <span className="time-digits primary">{minutes}</span>
          <span className="time-label">MINUTES</span>
        </div>

        <span className="time-separator">:</span>

        <div className="time-unit">
          <span className="time-digits primary">{seconds}</span>
          <span className="time-label">SECONDS</span>
        </div>

        <span className="time-subdigits">.{hundredths}</span>
      </div>

      {/* Control Buttons: Start, Pause, Reset (and optional Lap) */}
      <div className="controls-container">
        {!isRunning ? (
          <button
            className="btn-control btn-start"
            onClick={handleStart}
            type="button"
          >
            ▶ Start
          </button>
        ) : (
          <button
            className="btn-control btn-pause"
            onClick={handlePause}
            type="button"
          >
            ⏸ Pause
          </button>
        )}

        <button
          className="btn-control btn-reset"
          onClick={handleReset}
          disabled={time === 0 && !isRunning}
          type="button"
        >
          ↺ Reset
        </button>

        {time > 0 && (
          <button
            className="btn-control btn-lap"
            onClick={handleLap}
            disabled={!isRunning}
            type="button"
          >
            ⏱ Lap
          </button>
        )}
      </div>

      {/* Lap Times History */}
      {laps.length > 0 && (
        <div className="laps-container">
          <div className="laps-title">
            <span>Recorded Laps</span>
            <span>({laps.length})</span>
          </div>
          {laps.map((lapTime, index) => {
            const formatted = formatTimeParts(lapTime);
            return (
              <div key={index} className="lap-item">
                <span style={{ color: '#64748b' }}>Lap #{laps.length - index}</span>
                <span style={{ fontWeight: 600 }}>
                  {formatted.minutes}m {formatted.seconds}s.{formatted.hundredths}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default Stopwatch;
