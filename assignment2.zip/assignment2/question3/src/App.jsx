import React, { useState } from 'react';
import Stopwatch from './components/Stopwatch';
import './App.css';

function App() {
  const [isMounted, setIsMounted] = useState(true);

  return (
    <div className="app-container">
      <header className="page-header">
        <span className="assignment-badge">FSWD Assignment 2 • Question 3</span>
        <h1 className="page-title">React Stopwatch with Hooks</h1>
        <p className="page-description">
          A high-precision stopwatch built with <code>useState</code> and <code>useEffect</code>.
          Features <strong>Start</strong>, <strong>Pause</strong>, and <strong>Reset</strong> buttons, displays{' '}
          <strong>minutes</strong> and <strong>seconds</strong>, and guarantees interval cleanup on unmount.
        </p>
      </header>

      {/* Button to test component unmounting and interval cleanup */}
      <div className="toggle-unmount-bar">
        <button
          className="btn-toggle-unmount"
          onClick={() => setIsMounted((prev) => !prev)}
          type="button"
        >
          {isMounted ? '🧪 Simulate Component Unmount (Test Cleanup)' : '✨ Remount Stopwatch'}
        </button>
      </div>

      <section className="stopwatch-section">
        {isMounted ? (
          <Stopwatch />
        ) : (
          <div className="unmounted-placeholder">
            <h3>Component Unmounted</h3>
            <p>
              The <code>Stopwatch</code> component was removed from the DOM.
              The <code>useEffect</code> cleanup function executed <code>clearInterval(intervalId)</code>,
              ensuring zero memory leaks or background interval execution!
            </p>
          </div>
        )}
      </section>

      {/* Explanation of React Hooks Used */}
      <section className="explanation-card">
        <h2 className="explanation-title">Implementation Breakdown</h2>

        <div className="concepts-grid">
          <div className="concept-box">
            <h4>1. useState Hook</h4>
            <p>
              Stores <code>time</code> (elapsed milliseconds) and <code>isRunning</code> (boolean flag) to reactively trigger UI re-renders on state transitions.
            </p>
          </div>

          <div className="concept-box">
            <h4>2. useEffect Hook</h4>
            <p>
              Listens to <code>[isRunning]</code> dependency. When true, establishes an active <code>setInterval</code> that increments elapsed time.
            </p>
          </div>

          <div className="concept-box">
            <h4>3. Interval Cleanup on Unmount</h4>
            <p>
              Returns <code>() =&gt; clearInterval(intervalId)</code> as cleanup function, preventing memory leaks when the component unmounts or pauses.
            </p>
          </div>
        </div>

        <div className="code-display">
          <pre>
{`// Key useEffect & interval cleanup logic:
useEffect(() => {
  let intervalId = null;

  if (isRunning) {
    intervalId = setInterval(() => {
      setTime((prevTime) => prevTime + 10);
    }, 10);
  }

  // Cleanup: Clears interval when isRunning changes or when component UNMOUNTS
  return () => {
    if (intervalId) {
      clearInterval(intervalId);
    }
  };
}, [isRunning]);`}
          </pre>
        </div>
      </section>
    </div>
  );
}

export default App;
