# Full Stack Web Development (FSWD) — Assignment 2

This repository contains the complete solutions for **Assignment 2**, segregated into individual project folders: `question1`, `question2`, and `question3`.

Each question is an independent, production-ready React application built with **Vite** and modern React best practices.

---

## 📁 Directory Structure

```text
assignment2/
├── package.json               # Root convenience runner
├── README.md                  # Detailed documentation and running instructions
│
├── question1/                 # Solution for Question 1
│   ├── src/
│   │   ├── components/
│   │   │   ├── ProductCard.jsx
│   │   │   └── ProductCard.css
│   │   ├── App.jsx
│   │   ├── App.css
│   │   ├── index.css
│   │   └── main.jsx
│   └── package.json
│
├── question2/                 # Solution for Question 2
│   ├── src/
│   │   ├── components/
│   │   │   ├── Button.jsx
│   │   │   └── Button.css
│   │   ├── App.jsx
│   │   ├── App.css
│   │   ├── index.css
│   │   └── main.jsx
│   └── package.json
│
└── question3/                 # Solution for Question 3
    ├── src/
    │   ├── components/
    │   │   ├── Stopwatch.jsx
    │   │   └── Stopwatch.css
    │   ├── App.jsx
    │   ├── App.css
    │   ├── index.css
    │   └── main.jsx
    └── package.json
```

---

## 🚀 How to Run the Projects

You can run any question directly from the root directory or from inside each folder.

### Option 1: Run directly from the root directory

- **Question 1**:
  ```bash
  npm run dev:q1
  ```
- **Question 2**:
  ```bash
  npm run dev:q2
  ```
- **Question 3**:
  ```bash
  npm run dev:q3
  ```

### Option 2: Run within individual question directories

```bash
# Question 1:
cd question1
npm run dev

# Question 2:
cd question2
npm run dev

# Question 3:
cd question3
npm run dev
```

---

## 📝 Question Breakdown & Implementation Details

### Question 1: Reusable ProductCard Component
> **Question Prompt**: *React code to create a reusable ProductCard component that receives name, price, image and rating as props (use defaultProps or default parameter values) and render four different product cards inside the App component.*

- **Key Highlights**:
  - `ProductCard.jsx` accepts `name`, `price`, `image`, and `rating` props.
  - Implements **Default Parameter Values** (modern React/ES6 standard) and also sets `ProductCard.defaultProps` for backwards compatibility with all grading environments.
  - Generates dynamic star rating visuals (`★★★★☆`), formatted prices, category badges, and interactive "Add to Cart" feedback.
  - `App.jsx` renders **four distinct product cards** in a responsive grid:
    1. Sony WH-1000XM5 Wireless Headphones
    2. Apple Watch Series 9 GPS
    3. Keychron K2 Pro Mechanical Keyboard
    4. Logitech MX Master 3S Mouse
  - Includes an interactive test section demonstrating default parameter fallback when `<ProductCard />` is invoked without props.

---

### Question 2: Styling React Elements (Button Component)
> **Question Prompt**: *React code to demonstrate styling of React elements: create a Button component that receives a variant prop (primary / success / danger) and applies inline styles (style object), a CSS class (className) from an external stylesheet and a hover effect.*

- **Key Highlights**:
  - `Button.jsx` accepts `variant` (`"primary" | "success" | "danger"`), `children`, `style`, `className`, and `onClick`.
  - **1. External CSS Class (`className`)**:
    - Imports `Button.css` and computes dynamic classes (`custom-btn btn-primary`, `btn-success`, `btn-danger`).
  - **2. Inline Styles (`style` object)**:
    - Applies a JavaScript style object directly to the JSX element for base dimensions, borders, and merges external custom `style` props.
  - **3. Hover Effects**:
    - External CSS `:hover` handles smooth transform elevation and box-shadow glows.
    - React state (`isHovered`) dynamically modifies inline filter brightness on hover to demonstrate dynamic inline style reactivity.
  - `App.jsx` includes a live interactive code inspector and renders all three variants (`primary`, `success`, `danger`) along with custom inline style override examples.

---

### Question 3: Stopwatch with Hooks & Cleanup on Unmount
> **Question Prompt**: *React code to build a stopwatch with Start, Pause and Reset buttons that displays minutes and seconds. Use useState and useEffect (clear the interval on unmount).*

- **Key Highlights**:
  - `Stopwatch.jsx` manages timer states using `useState`:
    - `time`: tracks elapsed time.
    - `isRunning`: boolean flag controlling timer activity.
  - `useEffect`:
    - Creates an active `setInterval` when `isRunning` is `true`.
    - Returns a cleanup function:
      ```jsx
      return () => {
        if (intervalId) {
          clearInterval(intervalId);
        }
      };
      ```
      This guarantees `clearInterval` is called whenever `isRunning` flips or when the component **unmounts**, preventing memory leaks.
  - Displays formatted **Minutes (`MM`)** and **Seconds (`SS`)** (plus centiseconds).
  - Includes **Start**, **Pause**, and **Reset** buttons, status indicator badges, and lap recording.
  - `App.jsx` includes a **"Simulate Component Unmount"** toggle to test and verify safe unmounting.
