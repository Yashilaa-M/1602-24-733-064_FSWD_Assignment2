import React, { useState } from 'react';
import './Button.css';

/**
 * Button Component demonstrating 3 distinct React styling mechanisms:
 * 1. CSS Class (className) from an external stylesheet (Button.css)
 * 2. Inline Style Object (style={...}) with dynamic properties
 * 3. Hover Effect implemented via CSS :hover selectors and dynamic React hover state
 * 
 * @param {string} variant - 'primary' | 'success' | 'danger'
 * @param {React.ReactNode} children - Button label or nested JSX
 * @param {function} onClick - Click handler function
 * @param {object} style - Optional extra inline style object to merge
 * @param {string} className - Optional additional CSS class names
 * @param {boolean} disabled - Whether the button is disabled
 */
function Button({
  variant = 'primary',
  children,
  onClick,
  style = {},
  className = '',
  disabled = false,
  ...restProps
}) {
  // State to track hover for dynamic inline style demonstration
  const [isHovered, setIsHovered] = useState(false);

  // 1. External CSS Class resolution
  // Maps variant to corresponding class in Button.css (.btn-primary, .btn-success, .btn-danger)
  const variantClass = `btn-${variant}`;
  const combinedClassName = `custom-btn ${variantClass} ${className}`.trim();

  // 2. Inline Style Object demonstration
  // Base inline styles applied directly via JavaScript object
  const inlineStyles = {
    padding: '12px 24px',
    fontSize: '0.95rem',
    borderRadius: '10px',
    cursor: disabled ? 'not-allowed' : 'pointer',
    position: 'relative',
    overflow: 'hidden',
    // Dynamic inline style property adjusted on hover
    filter: isHovered && !disabled ? 'brightness(1.08)' : 'brightness(1)',
    transition: 'filter 0.2s ease, transform 0.2s ease',
    // Merge any user-provided inline styles
    ...style
  };

  return (
    <button
      className={combinedClassName}
      style={inlineStyles}
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      type="button"
      {...restProps}
    >
      {children}
    </button>
  );
}

// Fallback defaultProps
Button.defaultProps = {
  variant: 'primary',
  children: 'Click Me',
  style: {},
  className: '',
  disabled: false
};

export default Button;
