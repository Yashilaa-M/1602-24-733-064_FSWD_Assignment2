import React, { useState } from 'react';
import Button from './components/Button';
import './App.css';

function App() {
  const [selectedVariant, setSelectedVariant] = useState('primary');
  const [clickMessage, setClickMessage] = useState('');
  const [customLabel, setCustomLabel] = useState('Interactive Button');

  const handleButtonClick = (variant) => {
    setClickMessage(`Triggered click event on "${variant.toUpperCase()}" button!`);
    setTimeout(() => setClickMessage(''), 3000);
  };

  return (
    <div className="app-container">
      <header className="page-header">
        <span className="assignment-badge">FSWD Assignment 2 • Question 2</span>
        <h1 className="page-title">React Element Styling Demonstration</h1>
        <p className="page-description">
          Demonstrates styling of React elements using a <code>Button</code> component that receives a{' '}
          <code>variant</code> prop (<strong>primary</strong> / <strong>success</strong> / <strong>danger</strong>) and applies{' '}
          <strong>inline styles</strong>, an <strong>external stylesheet className</strong>, and <strong>hover effects</strong>.
        </p>
      </header>

      {/* Overview Cards */}
      <div className="features-banner">
        <div className="feature-pill">
          <div className="feature-icon">🎨</div>
          <div>
            <h4>1. Inline Style Object</h4>
            <p>Applies JavaScript object <code>style={'{...}'}</code> for padding, borderRadius, and dynamic filters.</p>
          </div>
        </div>
        <div className="feature-pill">
          <div className="feature-icon">📄</div>
          <div>
            <h4>2. External CSS Class</h4>
            <p>Imports <code>Button.css</code> and dynamically applies <code>.btn-primary</code>, <code>.btn-success</code>, or <code>.btn-danger</code>.</p>
          </div>
        </div>
        <div className="feature-pill">
          <div className="feature-icon">✨</div>
          <div>
            <h4>3. Hover & Transition Effects</h4>
            <p>Combines CSS <code>:hover</code> pseudo-selectors (elevation & shadow) with React state-based brightness filter.</p>
          </div>
        </div>
      </div>

      {/* Live Interactive Playground */}
      <section className="section-card">
        <h2 className="section-title">Interactive Component Inspector</h2>
        <p className="section-subtitle">
          Switch variants or hover over the button to inspect the applied classes, style objects, and hover interactions in real time.
        </p>

        <div className="interactive-demo-card">
          <div className="preview-box">
            <div className="variant-selector">
              {['primary', 'success', 'danger'].map((variant) => (
                <button
                  key={variant}
                  className={`variant-chip ${selectedVariant === variant ? 'active' : ''}`}
                  onClick={() => setSelectedVariant(variant)}
                  type="button"
                >
                  {variant.charAt(0).toUpperCase() + variant.slice(1)}
                </button>
              ))}
            </div>

            {/* The Reusable Button Component */}
            <Button
              variant={selectedVariant}
              onClick={() => handleButtonClick(selectedVariant)}
            >
              {selectedVariant.toUpperCase()} ACTION
            </Button>

            <span style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '14px' }}>
              👆 Hover or click me to test styling & hover state!
            </span>

            {clickMessage && (
              <div className="feedback-banner">
                ✓ {clickMessage}
              </div>
            )}
          </div>

          <div className="inspector-box">
            <span className="inspector-badge">Realtime Code Inspector</span>
            <pre>
{`// 1. JSX Component Call:
<Button variant="${selectedVariant}">
  ${selectedVariant.toUpperCase()} ACTION
</Button>

// 2. Computed External CSS Classes:
className="custom-btn btn-${selectedVariant}"

// 3. Computed Inline Style Object:
style={{
  padding: '12px 24px',
  fontSize: '0.95rem',
  borderRadius: '10px',
  filter: isHovered ? 'brightness(1.08)' : 'brightness(1)'
}}

// 4. External CSS Rules Applied:
.btn-${selectedVariant} { ... }
.btn-${selectedVariant}:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 14px ...;
}`}
            </pre>
          </div>
        </div>
      </section>

      {/* Gallery of all 3 variants side-by-side */}
      <section className="section-card">
        <h2 className="section-title">All Three Variants Side-by-Side</h2>
        <p className="section-subtitle">
          Direct rendering of each required variant: <code>primary</code>, <code>success</code>, and <code>danger</code>.
        </p>

        <div className="buttons-row">
          <Button variant="primary" onClick={() => handleButtonClick('primary')}>
            Primary Variant
          </Button>

          <Button variant="success" onClick={() => handleButtonClick('success')}>
            Success Variant
          </Button>

          <Button variant="danger" onClick={() => handleButtonClick('danger')}>
            Danger Variant
          </Button>

          <Button variant="primary" disabled>
            Disabled State
          </Button>
        </div>
      </section>

      {/* Inline Style Customization Demo */}
      <section className="section-card">
        <h2 className="section-title">Custom Inline Style Object Overrides</h2>
        <p className="section-subtitle">
          Passing an additional custom <code>style</code> prop to verify seamless merging of inline style objects.
        </p>

        <div className="buttons-row">
          <Button
            variant="primary"
            style={{ textTransform: 'uppercase', letterSpacing: '0.12em', padding: '14px 28px' }}
            onClick={() => handleButtonClick('custom primary')}
          >
            Custom Spacing & Uppercase
          </Button>

          <Button
            variant="success"
            style={{ borderRadius: '50px', border: '2px dashed #ffffff' }}
            onClick={() => handleButtonClick('pill success')}
          >
            Pill Shape + Dashed Border
          </Button>

          <Button
            variant="danger"
            style={{ fontWeight: '800', fontStyle: 'italic' }}
            onClick={() => handleButtonClick('italic danger')}
          >
            Bold Italic Danger
          </Button>
        </div>
      </section>
    </div>
  );
}

export default App;
