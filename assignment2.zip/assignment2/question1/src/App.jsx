import React, { useState } from 'react';
import ProductCard from './components/ProductCard';
import './App.css';

function App() {
  const [showDefaultDemo, setShowDefaultDemo] = useState(false);

  // Four different products to render as required
  const products = [
    {
      id: 1,
      name: 'Sony WH-1000XM5 Wireless Noise-Cancelling Headphones',
      price: 399.99,
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80',
      rating: 4.9,
      tag: 'Best Seller'
    },
    {
      id: 2,
      name: 'Apple Watch Series 9 GPS - Midnight Aluminum Case',
      price: 329.00,
      image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=600&q=80',
      rating: 4.8,
      tag: 'Popular'
    },
    {
      id: 3,
      name: 'Keychron K2 Pro Mechanical Wireless Keyboard (RGB)',
      price: 89.99,
      image: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=600&q=80',
      rating: 4.7,
      tag: 'Top Rated'
    },
    {
      id: 4,
      name: 'Logitech MX Master 3S Wireless Performance Mouse',
      price: 99.00,
      image: 'https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?auto=format&fit=crop&w=600&q=80',
      rating: 4.9,
      tag: 'Editor Choice'
    }
  ];

  return (
    <div className="app-container">
      <header className="page-header">
        <span className="assignment-badge">FSWD Assignment 2 • Question 1</span>
        <h1 className="page-title">Reusable ProductCard Component</h1>
        <p className="page-description">
          Demonstrates a reusable React <code>ProductCard</code> component that accepts{' '}
          <code>name</code>, <code>price</code>, <code>image</code>, and <code>rating</code> as props with default values, rendering four distinct product cards below.
        </p>
      </header>

      {/* Grid rendering the 4 distinct ProductCard components */}
      <section className="cards-grid">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            name={product.name}
            price={product.price}
            image={product.image}
            rating={product.rating}
            tag={product.tag}
          />
        ))}
      </section>

      <hr className="section-divider" />

      {/* Bonus interactive test to showcase defaultProps/default parameter values */}
      <section className="demo-box">
        <div className="demo-header">
          <div>
            <h2 className="demo-title">Default Props / Parameter Values Fallback Demo</h2>
            <p style={{ color: '#64748b', fontSize: '0.9rem', marginTop: '4px' }}>
              Test rendering a <code>&lt;ProductCard /&gt;</code> without passing any props to verify default prop fallback.
            </p>
          </div>
          <button
            onClick={() => setShowDefaultDemo((prev) => !prev)}
            style={{
              padding: '8px 16px',
              borderRadius: '8px',
              border: '1px solid #cbd5e1',
              background: showDefaultDemo ? '#eff6ff' : '#ffffff',
              color: showDefaultDemo ? '#2563eb' : '#334155',
              fontWeight: '600',
              cursor: 'pointer'
            }}
          >
            {showDefaultDemo ? 'Hide Default Card' : 'Show Default Card'}
          </button>
        </div>

        {showDefaultDemo && (
          <div style={{ maxWidth: '320px', margin: '20px auto 0' }}>
            <span className="demo-tag" style={{ display: 'inline-block', marginBottom: '8px' }}>
              Rendered with: &lt;ProductCard /&gt; (No props passed)
            </span>
            <ProductCard />
          </div>
        )}

        <div className="code-snippet">
          <code>
            {`// Usage Example:
<ProductCard
  name="Sony WH-1000XM5 Headphones"
  price={399.99}
  image="https://..."
  rating={4.9}
/>

// Default Parameter Fallback:
<ProductCard /> // Automatically uses default name, price, image & rating!`}
          </code>
        </div>
      </section>
    </div>
  );
}

export default App;
